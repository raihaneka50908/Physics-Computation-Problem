import numpy as np
import matplotlib.pyplot as plt

#Kondisi satu b=0
#Kondisi dua B^2 < wo^2
#Kondisi tiga b^2 > wo^2
#Kondisi empat b^2 = wo^2

def selesaikan_persamaan(t0,dt,tmax,b,wo_2,y0,v0):
    #x_dot_dot+b*x_dot+wo_2x=0

    #Inisiasi Array
    t=np.arange(t0,tmax,dt)
    y=np.zeros(len(t))
    v=np.zeros(len(t))
    y[0]=y0
    v[0]=v0

    for i in range(0,len(t)-1):
        y[i+1]=y[i]+v[i]*dt
        v[i+1]=v[i]+(-b*v[i]-wo_2*y[i])*dt
    return t,y,v

if __name__ == '__main__':
    t_1,y_1,v_1=selesaikan_persamaan(0,0.0001,50,0,15**2,2,0)
    t_2,y_2,v_2=selesaikan_persamaan(0,0.0001,50,0.75,15**2,2,0)
    t_3,y_3,v_3=selesaikan_persamaan(0,0.0001,50,15,0.75**2,2,0)
    t_4,y_4,v_4=selesaikan_persamaan(0,0.0001,50,15,15**2,2,0)
    plt.plot(t_1,y_1)
    plt.plot(t_2,y_2)
    plt.plot(t_3,y_3)
    plt.plot(t_4,y_4)
    plt.legend({"beta=0","beta^2<wo^2","beta^2>wo^2","beta^2=wo^2"})
    plt.show()